import { Container, Row, Col } from "reactstrap";
const JSONData = require("../data/data.json");
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";

export default function ViewTransaction() {
  const { account_no } = useParams();
  const transactions = JSONData.transactions.filter(
    (element) => element.account === account_no,
  );
  const { account, accountName, currencyCode, amount, transactionType } =
    transactions[0];
  return (
    <Container>
      <Row>
        <Col className="mt-3">
          <h2 className="float-left">Transaction {account_no}</h2>
          <Link to="/">
            <button className="btn btn-primary float-right">
              {`Back To Transactions`}
            </button>
          </Link>
        </Col>
      </Row>
      <hr />
      <Row>
        <Col xs="12">
          <div>
            <span className="font-weight-bolder">Account No.: </span>
            {account}
          </div>
          <div>
            <span className="font-weight-bolder">Account Name: </span>
            {accountName}
          </div>
          <div>
            <span className="font-weight-bolder">Currency Code: </span>
            {currencyCode}
          </div>
          <div>
            <span className="font-weight-bolder">Amount: </span>
            {amount}
          </div>
          <div>
            <span className="font-weight-bolder">Transaction Type: </span>
            {transactionType}
          </div>
        </Col>
      </Row>
    </Container>
  );
}

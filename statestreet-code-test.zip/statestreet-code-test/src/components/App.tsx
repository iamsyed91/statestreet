import "./../assets/scss/App.scss";
import "bootstrap/dist/css/bootstrap.min.css";

import { HashRouter as Router, Routes, Route } from "react-router-dom";

import Transactions from "../pages/Transactions";
import ViewTransaction from "../pages/ViewTransaction";

const App = () => (
  <Router>
    <Routes>
      <Route path="/" element={<Transactions />} />
      <Route
        path="/view-transaction/:account_no"
        element={<ViewTransaction />}
      />
    </Routes>
  </Router>
);

export default App;

import { render, screen } from "@testing-library/react";
import App from "../src/components/App";

describe("App", () => {
  test("should render My Transactions heading", () => {
    render(<App />);
    expect(screen.getByText("My Transactions")).toBeTruthy();
  });

  test("should render Filters", () => {
    render(<App />);
    expect(screen.getByText("Filters")).toBeTruthy();
  });
});
